#include <iostream>
using namespace std;
int main(){
			int i, j, sum=0;
			int array[3][3];
			
			for(int i= 0; i<3; i++){
				for(int j= 0; j< 3; j++){
					cout<<"matrix["<<i<<"]["<<j<<"] = ";   
					cin>>array[i][j];  
				
					if(i > j){
					sum= sum+array[i][j];
					} 
				}
					cout<<endl;
			}
				cout<<"Sum of lower triangular matrix is "<<sum;
				
		return 0;
}


