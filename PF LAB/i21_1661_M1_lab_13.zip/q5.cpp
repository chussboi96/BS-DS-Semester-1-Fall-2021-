#include <iostream>
using namespace std;
int main(){
   	     	string stryng = " Pakistan Zindabad";
    		char checkCharacter = 'a';
   			int count = 0;

    for (int i = 0; i < stryng.size(); i++){
        if (stryngi] ==  checkCharacter){
            ++ count;					}
    }
	
		 cout << "Number of " << checkCharacter << " = " << count;
	
	 return 0;
}
