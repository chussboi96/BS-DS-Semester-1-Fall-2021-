#include <iostream>
using namespace std;
void displayC(int c[3][3]){
	for(int i= 0; i< 3; ++i){
        for(int j= 0; j< 3; ++j){
            cout<<c[i][j] << "  ";
    	}
        cout<<endl;
    }
}
int main(){
		int a[3][3] = {0, 2, 3, 1, 7, 9, 1, 2, 0};
		int b[3][3] = {5, 0, 2, 10, 1, 1, 8, 2, 4};
        	int c[3][3], i, j;
        
    for(i = 0; i < 3; ++i){
        for(j = 0; j < 3; ++j){
            c[i][j] = a[i][j] + b[i][j];     }
	}
	
	cout<<endl<<"Sum of two matrix is: " << endl;
    
	displayC(c);

    return 0;
}
