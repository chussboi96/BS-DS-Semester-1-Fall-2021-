#include <iostream>
using namespace std;
void wow(int matrix[5][5]){
	
				for(int i= 0; i< 5; i++){
				for(int j= 0; j<5; j++){
					cout<<"matrix["<<i<<"]["<<j<<"] = ";   
					
					cin>>matrix[i][j];   }
					
					cout<<endl;
			}
	
	
}
int main(){
			int i, j;
			int matrix[5][5];
			
		
				cout<<"The elements of array are matrix"<<endl;
				wow(matrix);
				
		return 0;
}
