#include<iostream>
#include<string>
using namespace std;
int main()
  {
    string x,y;
    float z;
    cout<<"Enter your Name"<<endl;
    cin>>x;
    cout<<"Enter your Roll Number"<<endl;
    cin>>y;
    cout<<"Enter your CGPA"<<"   "<<endl;
    cin>>z;
    cout<<"Name is"<<" "<<x<<endl;
    cout<<"Roll Number is"<<"  "<<y<<endl;
    cout<<"CGPA is"<<" "<<z<<endl;  
   return 0;
  }