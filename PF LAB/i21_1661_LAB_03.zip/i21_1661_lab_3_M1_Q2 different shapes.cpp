#include<iostream>
using namespace std;
int main()
{
  
  cout<<"             THIS PROGRAM SHOWS DIFFERENT SHAPES              "<<endl;
  
  cout<<"                 FIG 1"<<endl;   
   
   cout<<"              *                 \n"
       <<"             * *                \n"
       <<"            *   *               \n"
       <<"           *     *              \n"
       <<"          *       *             \n"
       <<"         *         *            \n"
       <<"        *           *           \n"
       <<"         *         *            \n"
       <<"          *       *             \n"
       <<"           *     *              \n"
       <<"            *   *               \n"
       <<"             * *                \n"
       <<"              *                 \n";

 cout<<"                   FIG 2"<<endl;   
   

   cout<<"       ***************                   " <<endl
       <<"       *************                    "  <<endl  
       <<"       ***********                  "<<endl
       <<"       **********                  "     <<endl
       <<"       *********                 "    <<endl
       <<"       ********                      "<<endl
       <<"       *******                       "<<endl
       <<"       ******                       "<<endl
       <<"       *****                     "<<endl
       <<"       ****                     "<<endl 
       <<"       ***               " <<endl
       <<"       **                " <<endl
       <<"       *                  ";

 cout<<"                   FIG 3"<<endl;   
   

 
   cout<<"       *************                   " <<endl
       <<"        ************                    "  <<endl  
       <<"         ***********                  "<<endl
       <<"          **********                  "     <<endl
       <<"           *********                 "    <<endl
       <<"            ********                      "<<endl
       <<"             *******                       "<<endl
       <<"              ******                       "<<endl
       <<"               *****                     "<<endl
       <<"                ****                     "<<endl 
       <<"                 ***   "
       <<"                  **       "<<endl
       <<"                   *            " ;

 cout<<"                   FIG 4"         <<endl;
   cout<<"         ******          "                 <<endl;
    cout<<"       *      *          "             <<endl;  
    cout<<"      *        *      "             <<endl;
    cout<<"       *      *       "              <<endl;
    cout<<"        ******            "            <<endl;   
      



return 0;
}
