#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
cout<<setw(42)<< "________________________________ "<<endl;
cout<<setw(9)<<"/\\" <<setw(33)<<"\\"<<endl;
cout<<setw(9)<<"/ \\" <<setw(23)<<"___ ___ " <<setw(11)<<"\\"<<endl;
cout<<setw(11)<<"/    \\" <<setw(14)<<"\\" <<setw(4)<<"\\"<<setw(4)<<"\\" <<setw(11)<<"\\"<<endl;
cout<<setw(12)<<"/      \\" <<setw(22)<<"\\===\\===\\" <<setw(11)<<"\\"<<endl;
cout<<setw(13)<<"/        \\" <<setw(23)<<"\\___\\___\\ " <<setw(10)<<"\\"<<endl;
cout<<setw(14)<<"/          \\"<<setw(33)<<"\\"<<endl;
cout<<setw(15)<<"/            \\"<<setw(33)<<"\\"<<endl;
cout<<setw(10)<<"/______________\\"<<setw(33)<<"\\"<<endl;
cout<<setw(22)<<":              :\\________________________________\\"<<endl;
cout<<setw(22)<<":              :                                :"<<endl;
cout<<setw(22)<<":              :                                :"<<endl;
cout<<setw(22)<<":              :                                :"<<endl;
cout<<setw(26)<<":    ______    :          _____                 :"<<endl;
cout<<setw(22)<<":   :      :   :          :_:_:                 :"<<endl;
cout<<setw(22)<<":   :      :   :          :_:_:                 :"<<endl;
cout<<setw(22)<<":   :      :   :                                :"<<endl;
cout<<setw(25)<<":   :    . :   :                                :"<<endl;
cout<<setw(22)<<":   :      :   :                                :"<<endl;
cout<<setw(22)<<":   :      :   :                                :"<<endl;
cout<<setw(22)<<":___:______:___:________________________________:"<<endl;
}
