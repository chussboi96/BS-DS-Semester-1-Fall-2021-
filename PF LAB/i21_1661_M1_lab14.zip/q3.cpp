#include <iostream>
using namespace std;
int main(){
		 int num, item1 = 3, item2= 5;
		 int item[item1][item2]= { {1, 3, 5, 7, 9},
		 						   {2, 4, 6, 8, 10},
		 						   {1, 2, 3, 5, 7}  };
		cout<<"Enter a number to search in Array:";
    	cin>>num;
      
      for(int i = 0; i < 3; i++){
	      	for(int j= 0; j< 5; j++){
	        if( item[i][j] == num){
	            cout << "Element found at index "<<i<<" "<<j;
	            break;
	            }
		    }
        }
		 
	return 0;
}
