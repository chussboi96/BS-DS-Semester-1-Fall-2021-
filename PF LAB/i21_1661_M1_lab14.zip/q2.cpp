#include <iostream>
using namespace std;
int hours2(int &hours, int &minutes){
	int minutes1= minutes / 60;
	int hours1= hours + minutes1;
	
	return hours1;
}
int minutes2(int &hours, int &minutes){
	int new_hours= hours * 60;
	int new_minutes= minutes + new_hours;
	
	return new_minutes;
}
int main(){
		  int choice, minutes, hours;
		  
		  cout<<"Enter hours: ";
		  cin>>hours;
		  cout<<"Enter minutes: ";
		  cin>>minutes;
		  
		  cout<<"CONVERSION"<<endl;
		  cout<<"1-All into hours\n";
		  cout<<"1-All into minutes\nEnter your choice:";
		  cin>>choice;
		  
		  switch(choice){
		  	case 1:
		  		cout<<hours2(hours, minutes);
		  		break;
		  	case 2:
		  		cout<<minutes2(hours, minutes);
		  		break;
		  }
		  
	return 0; 
}
