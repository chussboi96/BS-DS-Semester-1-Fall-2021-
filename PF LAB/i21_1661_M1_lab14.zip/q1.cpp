#include <iostream>
#include <math.h>
using namespace std;
void Square(int &num){
    num = num*num;
}
void Power(int exponent, int base, int &result){
    result = pow(base, exponent);
}

int main(){
	    int num;
	    cout<<"Input a number: "<<endl;
	    cin>>num;
	    cout<<endl;
	    cout<<"NUMBER \t SQUARES \t POWERS";
	    for(int x= 1; x<= 10; x++){
	        int y, result;
	        cout<<y;
	        Power(y, num, result);
	        Square(num);
    }

    return 0;
}
