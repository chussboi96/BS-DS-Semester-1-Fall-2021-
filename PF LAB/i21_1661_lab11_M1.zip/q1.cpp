#include <iostream>
using namespace std;
int main() {

   int num1, num2, multiply= 0, i;
   
   cout << "Enter two numbers: ";
   cin >> num1 >> num2;
   

   for(i= 0; i < num1; i++){
    
      multiply = multiply + num2;   }
   
    
    cout << "Multiplication of two numbers is "<<multiply;
    
 return 0;
}