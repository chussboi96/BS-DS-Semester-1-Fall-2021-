#include <iostream>
using namespace std;
int main(){
            int i, number, j;
            
            cout<<"Enter an integer upto which u want to take table: ";
            cin>>number;
            
            for(j= 2; j<= number; j++){
                
                cout<<"************Table of"<<j<<"************"<<endl;
                for(i= 1; i<= 10; i++){
                cout<<j*i<<endl;    }
                
                
            }
            

    return 0;
}
