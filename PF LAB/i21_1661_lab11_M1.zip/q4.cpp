#include <iostream>
using namespace std;
int main(){
            int rows, space; 
             cout<<"Enter number of rows: ";
             cin>>rows;
             
            int nice= 2*rows;
             
       for(int i= 1; i<= rows; i++){
           
          for(space= 1; space< i; space++){
            cout<<" ";                  }
              for(int j= 1; j< nice ; j++){
               cout<<"*";               }
        cout<<endl;
        nice= nice -2; 
        
}
        
    return 0;
}