#include <iostream>
using namespace std;
int main(){
             int rows;
             char alphabet ='a';
           
           cout<<"Enter number of rows: ";
           cin>>rows;

        for(int i= 1; i<= rows; ++i){
                alphabet ='a';
              for(int j= 1; j<= i; ++j){
                  cout<<alphabet;
                  alphabet++;}
             cout <<endl;
       }
    return 0;
}
