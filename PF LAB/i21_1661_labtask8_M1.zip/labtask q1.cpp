#include <iostream>
using namespace std;

int main()
{
    float angleA, angleB, angleC;
    float total_angle;
    
    cout<<"Enter tha value of angle A: ";
    cin>>angleA;
    cout<<"Enter tha value of angle B: ";
    cin>>angleB;
    cout<<"Enter tha value of angle c: ";
    cin>>angleC;
    
    total_angle= angleA + angleB + angleC;
    
    if (total_angle == 180){
    
    cout<<"This triangle is valid."<<endl;
    if (angleA>angleB ){
        if(angleA>angleB)
    cout<<"The angle A is the largest."<<endl; }
    else if(angleB>angleA){
        if (angleB>angleC)
    cout<<"The angle B is the largest."<<endl; }
    else if(angleC>angleA){
        if(angleC>angleB)
    cout<<"The angle C is the largest."<<endl; }
    
    }
    else cout<<"This triangle is invalid.";
    

    return 0;
}
