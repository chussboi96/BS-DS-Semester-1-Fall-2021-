#include<iostream>
using namespace std;
 
int main()
{
    float num1, num2;
    char calculator;
    
    cout<<"Enter the first integer: ";
    cin>>num1;
    cout<<"Enter the second integer: ";
    cin>>num2;
    cout<<"Enter any one of the following operators: '+' or '-' or '/' or '*' : ";
    cin>>calculator;
    
    if (calculator == '+')
    cout<<"The sum of the two integers is "<<num1+num2; 
    else if(calculator == '-'){
    cout<<"The difference of the two integers is "<<num1-num2; }
    else if(calculator == '/'){
    cout<<"The division of the two integers is "<<(num1)/(num2); }
    else if(calculator == '*'){
    cout<<"The product of the two integers is "<<num1*num2; }
    
    else
    cout<<"Invalid operator."<<endl;
    return 0;
}