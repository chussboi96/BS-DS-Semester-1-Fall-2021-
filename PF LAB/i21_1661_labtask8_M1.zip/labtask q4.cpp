#include<iostream>
#include<string>
using namespace std;

string find_return_day(int length_of_stay ,int starting_day){
    int return_DAY;
    return_DAY = (length_of_stay + starting_day) % 7 ;
    
    if(return_DAY == 0){
    return "Sunday"; }
    else if(return_DAY == 1){
    return "Monday"; }
    else if(return_DAY == 2){
    return "Tuesday"; }
    else if(return_DAY == 3){
    return "Wednesday"; }
    else if(return_DAY == 4){
    return "Thursday";  }
    else if(return_DAY == 5){
    return "Friday";    }
        
    else if(return_DAY == 6){
    return "Saturday";  }
    else 
    return "inavlid.";
 }    

int main(){
    int starting_day, length_of_stay, return_DAY;
    cout<<"Enter the starting day of your holiday: ";
    cin>>starting_day;
    cout<<"Enter the length of your stay (in days) : ";
    cin>>length_of_stay;
    
    cout<<"Your return day wil be "<<find_return_day(starting_day, length_of_stay);
     
    return 0;
    
    
}