#include<iostream>
using namespace std;
 
int main()
{
    int number, remaining;
 
    cout << "Enter the number : ";
    cin >> number;
    remaining = number % 2;
    if (remaining == 0)
        cout << number << " is even. " << endl;
    else
        cout << number << " is odd. " << endl;
 
    return 0;
}