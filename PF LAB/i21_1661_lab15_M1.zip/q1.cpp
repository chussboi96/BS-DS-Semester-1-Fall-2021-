#include <iostream>
#include <fstream>
using namespace std;
int main(){
		ofstream myfile;
		myfile.open("File1.txt");
		
		myfile<<"Programming Fundamentals BSDS. It is our Lab_14.\nOur subject is \"Programming Fundamentals\".";
		
		myfile.close();
		
	return 0;
}
