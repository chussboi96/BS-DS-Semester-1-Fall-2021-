#include <iostream>
#include <fstream>
using namespace std;
int main(){
		fstream myfile;
		myfile.open("File2.txt");
		fstream myfile1;
		myfile1.open("File4.txt");
		
		char ch;
		while(myfile.get(ch)){
			ch += 100;	
			myfile1<<ch;
	}
		myfile.close();
		
	return 0;
}
