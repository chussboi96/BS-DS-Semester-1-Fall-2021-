#include <iostream>
#include <fstream>
using namespace std;
void display(ifstream &fin){
		char ch;
		while(fin.get(ch)){
			cout<<ch;		}
}
void alphabets(ifstream &fin){
	char ch;
	int count=0;
	while(fin.get(ch)){
		if( (ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') )
		count++;
	}
	cout<<"\n\nNumber of alphabets in file are "<<count;
}
void word(ifstream &fin){
	char ch;
	int count= 1;
	while(fin.get(ch)){
		if( ch == ' ' || ch == '\n' )
		count++;					
		}
		cout<<"\n\nTotal number of words are "<<count;
}
int main(){
		ifstream myfile;
		myfile.open("File2.txt");
		
		display(myfile);	
		myfile.clear();
		myfile.seekg(0);
		
		alphabets(myfile);
		myfile.clear();
		myfile.seekg(0);
		
		word(myfile);
		myfile.close();
		
	return 0;
}
