#include <iostream>
using namespace std;

void Hammad(){
 
        cout<<" The upper limit of the integer is : 2147483647"<<endl;
        cout<<"The lower limit of the integer is : -2147483647"<<endl;

                       }

int main(){

           Hammad();

           return 0;
     
            }
