#include <iostream>
using namespace std;

int Hammad(float, float);
int main(){
//Calculating volume of sphere in function & displaying in main function
              float Pi=3.1415, r;
              float volume;

              cin>>r;

              volume= (4/3)*Pi*(r*r*r);

              cout<<"The volume of the sphere is "<<volume<<endl;

              return 0;
 
                }

int Hammad(float Pi, float volume){

                                    return 0;
 
                                     }
          
