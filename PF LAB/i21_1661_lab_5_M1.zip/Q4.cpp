#include <iostream>
using namespace std;

int Q4(float, float, float);
int main(){
//Calculating third angle of a triangle
// Angle = a - which is to be calculated

            float a, x, y;
            cout<<"Enter value of first Angle"<<endl;
            cin>>x;
            cout<<"Enter value of second Angle"<<endl;
            cin>>y;
            a=180-(x+y);
            cout<<"The value of 3rd angle is "<<a<<endl; 
            return 0;
         
            }

int Q4(float a, float x, float y){

                                    return 0;
 
                                     }
