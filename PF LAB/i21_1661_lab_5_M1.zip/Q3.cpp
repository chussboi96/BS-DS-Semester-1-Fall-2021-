#include <iostream>
using namespace std;

int timesTen(int, int);
int main(){

         int x;
         cin>>x;

         cout<<"The answer of input multiplied by 10 is "<<x*10<<endl;

             return 0;
         
            }

int timesTen(int x, int y){

                                    return x*10;
 
                                     }
