#include <iostream>
using namespace std;
void TIKKAFUNC(int TIKKAs)
{
    int remaining, notes_of_750, notes_of_450, notes_of_350;
    int notes_of_75, notes_of_18, notes_of_1;
         
         cout<<"Currency Note       :Number"<<endl;
         
         if (TIKKAs >= 1){
            notes_of_750 = TIKKAs/750;
            cout<<"750                 :"<<notes_of_750<<endl;
            remaining = TIKKAs%750;
            
            notes_of_450 = remaining/450;
            cout<<"450                 :"<<notes_of_450<<endl;
            remaining = remaining%450;
            
            notes_of_350 = remaining/350;
            cout<<"350                 :"<<notes_of_350<<endl;
            remaining = remaining%350;
            
            notes_of_75 = remaining/75;
            cout<<"75                  :"<<notes_of_75<<endl;
            remaining = remaining%75;
            
            notes_of_18 = remaining/18;
            cout<<"18                  :"<<notes_of_18<<endl;
            remaining = remaining%18;
            
            notes_of_1 = remaining/1;
            cout<<"1                   :"<<notes_of_1<<endl;
            
         }
         
         else cout<<"Invalid input";
}
         
         
         
int main(){
         int TIKKAs;
         cout<<"Enter the amount of Tikka's : ";
         cin>>TIKKAs;
         TIKKAFUNC(TIKKAs);
  
   return 0;
}
