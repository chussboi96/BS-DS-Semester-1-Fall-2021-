#include <iostream>
using namespace std;

int main(){
       
        // Company total sales = $8.6 million
        // EC = East coast sales division generates 58% of total sales.

           long sales = 8600000, EC = .58*sales;
           
           cout<<"East coast sales division of the company will generate $"<<EC<<"."<<endl;
           
           return 0;
    
           }