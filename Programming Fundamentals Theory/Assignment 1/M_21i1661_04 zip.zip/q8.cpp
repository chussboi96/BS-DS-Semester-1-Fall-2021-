#include <iostream>
using namespace std;

int main(){
       
        // Program to find out how many bytes a data type uses
        
        cout<<"The char data type uses "<<sizeof(char)<<" bytes."<<endl;
        cout<<"The int data type uses " <<sizeof(int) <<" bytes."<<endl;
        cout<<"The float data type uses "<<sizeof(float)<<" bytes."<<endl;
        cout<<"The double data type uses "<<sizeof(double)<<" bytes."<<endl;
        
        
        return 0;
        
            }