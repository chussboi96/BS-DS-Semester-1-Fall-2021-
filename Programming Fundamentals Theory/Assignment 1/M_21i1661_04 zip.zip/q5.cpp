#include <iostream>
using namespace std;

int main(){
       
        // Program to calculate sum AND average of 5 variables
        int a= 28, b= 32, c= 37, d= 24, e= 33;
        float sum, avg;
        
        sum = a+b+c+d+e;
        
        avg = (sum)/5;
        cout<<"The average of these five variables is "<<avg<<endl;
        
        return 0;
           
             } 