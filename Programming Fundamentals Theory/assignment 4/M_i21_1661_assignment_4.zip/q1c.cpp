#include <iostream>
using namespace std;
int main(){
            int n= 8;
    
	for (int i= 7; i> 0; i--)
{
    	for (int space= 1; space<= n - i; space++)
        	cout<<" ";
    
    	for (int j= 1; j<= i; j++)
        	cout<<j;

   		for(int k= i-1; k> 0; k--)
       		cout<<k;

    cout << endl;
}

    return 0;
}
